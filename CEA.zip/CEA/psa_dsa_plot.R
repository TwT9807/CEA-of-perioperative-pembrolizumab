library(dplyr)
library(heemod)
library(ggplot2)
library(showtext)
library(tidyr)

rm(list=ls(all=TRUE))
setwd("E:\\Keynote-671 Cost-Effectiveness\\rstudio-export0626")
myfiles = list.files(pattern = 'res_psa')

for (i in seq_along(myfiles)) {
  variable_name <- paste0("data", i)
  load(myfiles[i])
  assign(variable_name, res_psa$psa)
}

datanames <- ls(pattern = "^data")
plus = 0
for (dataname in datanames) {
  data <- get(dataname)
  data$.index <- data$.index + plus
  plus = plus + 50
  assign(dataname, data, envir = .GlobalEnv)
}

data <- data.frame()
for (dataname in datanames) {
  data <- rbind(data, get(dataname))
}

### max and min
cost_pem <- c(min(data[which(data$.strategy_names == "pem"), ]$.cost)/100,
              max(data[which(data$.strategy_names == "pem"), ]$.cost)/100)
effect_pem <- c(min(data[which(data$.strategy_names == "pem"), ]$.effect/100),
              max(data[which(data$.strategy_names == "pem"), ]$.effect)/100)
cost_pla <- c(min(data[which(data$.strategy_names == "pla"), ]$.cost)/100,
              max(data[which(data$.strategy_names == "pla"), ]$.cost)/100)
effect_pla <- c(min(data[which(data$.strategy_names == "pla"), ]$.effect)/100,
              max(data[which(data$.strategy_names == "pla"), ]$.effect)/100)
ICERs <- c()
for (i in 1:1000) {
  pair <- data[which(data$.index == i),]
  ICER <- (pair[which(pair$.strategy_names == "pem"),]$.cost -
             pair[which(pair$.strategy_names == "pla"),]$.cost)/
  (pair[which(pair$.strategy_names == "pem"),]$.effect -
      pair[which(pair$.strategy_names == "pla"),]$.effect)
  ICERs <- rbind(ICERs, ICER)  
}
ICER <- c(min(ICERs), max(ICERs))
gt_150000 <- (ICERs[which(ICERs < 150000),] %>% length())/1000
  
  
### plots
res_psa$psa <- data

showtext_auto(enable = TRUE)
font_add('Arial', 'arial.ttf')

psa_ce <- plot(res_psa, type = "ce") + 
  geom_abline(slope = 150000, intercept = 0, color = "grey 20", linetype = "dashed") +
  annotate("text", x = 0.8, y = 160000, label = "WTP = $150000/QALY", size = 3) +
  theme(text = element_text(size = 12))
ggsave("PSA_ce.pdf", plot = psa_ce, units = "cm", width = 20, height = 10.4)

psa_ac <-
  plot(res_psa,
       type = "ac",
       max_wtp = 300000,
       log_scale = FALSE) +
  geom_vline(xintercept = 150000,
             linetype = "dashed",
             color = "grey 20") +
  scale_x_continuous(breaks = seq(from = 0, to = 300000, by = 50000)) +
  xlab("Willingness to pay ($/QALY)") +
  theme(text = element_text(size = 12))
ggsave("PSA_ac.pdf", plot = psa_ac, units = "cm", width = 20, height = 10.4)

#DSA
rm(list=ls(all=TRUE))
setwd("E:\\Keynote-671 Cost-Effectiveness\\rstudio-export0626")
load("res_dsa.RData")

dsa_data <- as.data.frame(res_dsa$dsa)

ICER_DSA <- data.frame()

for (parameter in unique(res_dsa$dsa$.par_names)) {
  high <- subset(dsa_data, dsa_data$.par_names == parameter) %>%
    subset(., .$.par_value_eval > mean(.$.par_value_eval))
  ICER_high <- (high$.cost[high$.strategy_names == "pem"] -
                  high$.cost[high$.strategy_names == "pla"]) / (high$.effect[high$.strategy_names == "pem"] -
                                                                  high$.effect[high$.strategy_names == "pla"])
  low <- subset(dsa_data, dsa_data$.par_names == parameter) %>%
    subset(., .$.par_value_eval < mean(.$.par_value_eval))
  ICER_low <- (low$.cost[low$.strategy_names == "pem"] -
                 low$.cost[low$.strategy_names == "pla"]) / (low$.effect[low$.strategy_names == "pem"] -
                                                               low$.effect[low$.strategy_names == "pla"])

  ICER_DSA <- rbind(ICER_DSA, c(parameter, ICER_low, ICER_high))
}

colnames(ICER_DSA) <- c("Parameter", "Lower_Bound", "Upper_Bound")
ICER_DSA$Lower_Bound <- as.numeric(ICER_DSA$Lower_Bound)
ICER_DSA$Upper_Bound <- as.numeric(ICER_DSA$Upper_Bound)

ICER_base <- 94222.29

translation <- c("cSurgery" = "Cost of surgery per event",
                 "cRadiotherapy" = "Cost of radiotherapy per event",
                 "cPemetrexed" = "Cost of pemetrexed per mg",
                 "cCisplatin" = "Cost of cisplatin per mg",
                 "cGemcitabine" = "Cost of gemcitabine per mg",
                 "cPembrolizumab" = "Cost of pembrolizumab per mg",
                 "cNeutropenia" = "Cost of neutropenia management per event",
                 "cAnemia" = "Cost of anemia management per event",
                 "cThrombocytopenia" = "Cost of thrombocytopenia management per event",
                 "cChemo_iv_infusion_1hr" = "Cost of chemotherapy IV (1st hour)",
                 "cChemo_iv_infusion_addlhr" = "Cost of chemotherapy IV of additional one hour",
                 "cChemo_iv_infusion_each_addl_seq" = "Cost of chemotherapy IV of each additional hour",
                 "cFollow_up" = "Cost of follow-up per cycle",
                 "cEnd_of_life" = "Cost of life ending",
                 "cBest_supportive_care" = "Cost of best supportive care per cycle",
                 "Discount_rate" = "Discount rate",
                 "BSA" = "Body surface area",
                 "uRadiotherapy" = "Utility of survival after radiotherapy",
                 "uSurgery" = "Utility of survival after surgery",
                 "uPF" = "Utility of progression-free survival",
                 "uPD" = "Utility of survival with disease progression",
                 "uNeutropenia" = "Disutility of neutropenia",
                 "uAnemia" = "Disutility of anemia",
                 "uThrombocytopenia" = "Disutility of thrombocytopenia",
                 "nNeutropenia_pem" = "Proportion of patients with neutropenia using pembrolizumab",
                 "nAnemia_pem" = "Proportion of patients with anemia using pembrolizumab",
                 "nThrombocytopenia_pem" = "Proportion of patients with thrombocytopenia using pembrolizumab",
                 "nNeutropenia_pla" = "Proportion of patients with neutropenia using placebo",
                 "nAnemia_pla" = "Proportion of patients with anemia using placebo",
                 "nThrombocytopenia_pla" = "Proportion of patients with thrombocytopenia using placebo",
                 "nS_R_death" = "Motality rate of surgery",
                 "nNTS_pem" = "Cases having surgery or radiotherapy/Cases taking neoadjuvant pembrolizumab",
                 "nSTA_pem" = "Cases taking adjuvant pembrolizumab/Cases taking surgery or radiotherapy",
                 "nNTS_pla" = "Cases having surgery or radiotherapy/Cases taking neoadjuvant placebo",
                 "nSTA_pla" = "Cases taking adjuvant placebo/Cases taking surgery or radiotherapy",
                 "nDiscontinue_pem_neo" = "Proportion of patients who discontinued neoadjuvant pembrolizumab",
                 "nDiscontinue_pem_adj" = "Proportion of patients who discontinued adjuvant pembrolizumab",
                 "nDiscontinue_pla_neo" = "Proportion of patients who discontinued neoadjuvant placebo",
                 "nDiscontinue_pla_adj" = "Proportion of patients who discontinued adjuvant placebo"
)

ICER_DSA$Parameter <- translation[ICER_DSA$Parameter]

order.parameters <- ICER_DSA %>%
  mutate(ICER_diff = abs(Upper_Bound - Lower_Bound)) %>%
  arrange(ICER_diff) %>%
  mutate(Parameter = factor(x = Parameter, levels = Parameter)) %>%
  select(Parameter) %>%
  unlist() %>%
  levels()

width <- 0.45

ICER_DSA2 <- ICER_DSA %>%
  mutate(ICER_diff = abs(Upper_Bound - Lower_Bound)) %>%
  gather(key = 'type', value = 'output.value', Lower_Bound:Upper_Bound) %>%
  select(Parameter, type, output.value, ICER_diff) %>%
  mutate(
    Parameter = factor(Parameter, levels = order.parameters),
    ymin = pmin(output.value, ICER_base),
    ymax = pmax(output.value, ICER_base),
    xmin = as.numeric(Parameter) - width / 2,
    xmax = as.numeric(Parameter) + width / 2
  )

levels_to_keep <- levels(ICER_DSA2$Parameter) %>%
.[(length(.) - 19):length(.)]

order.parameters_less <- order.parameters[order.parameters %in% levels_to_keep]

ICER_DSA_less <- ICER_DSA %>%
  .[(.$Parameter %in% levels_to_keep), ] %>%
  mutate(ICER_diff = abs(Upper_Bound - Lower_Bound)) %>%
  gather(key = 'type', value = 'output.value', Lower_Bound:Upper_Bound) %>%
  select(Parameter, type, output.value, ICER_diff) %>%
  mutate(
    Parameter = factor(Parameter, levels = order.parameters_less),
    ymin = pmin(output.value, ICER_base),
    ymax = pmax(output.value, ICER_base),
    xmin = as.numeric(Parameter) - width / 2,
    xmax = as.numeric(Parameter) + width / 2
  )


showtext_auto(enable = TRUE)
font_add('Arial', 'arial.ttf')

dsa <- ggplot() +
  geom_rect(data = ICER_DSA2,
            aes(
              ymax = ymax,
              ymin = ymin,
              xmax = xmax,
              xmin = xmin,
              fill = type
            )) +
  theme_bw() +
  theme(
    axis.title.y = element_blank(),
    legend.position = c(0.85, 0.15),
    legend.title = element_blank(),
    text = element_text(size = 20)
  ) +
  geom_hline(yintercept = ICER_base) +
  scale_x_continuous(breaks = c(1:length(order.parameters)),
                     labels = order.parameters) +
  coord_flip() +
  scale_fill_manual(values = c("#5C8286",  "#BFBFBF")) +
  labs(x = "", y = "ICER ($/QALY)")

ggsave("DSA.pdf", dsa, height = 15, width = 18)

dsa_less <- ggplot() +
  geom_rect(data = ICER_DSA_less,
            aes(
              ymax = ymax,
              ymin = ymin,
              xmax = xmax,
              xmin = xmin,
              fill = type
            )) +
  theme_bw() +
  theme(
    axis.title.y = element_blank(),
    legend.position = c(0.85, 0.15),
    legend.title = element_blank(),
    text = element_text(size = 20)
  ) +
  geom_hline(yintercept = ICER_base) +
  scale_x_continuous(breaks = c(1:length(order.parameters_less)),
                     labels = order.parameters_less) +
  coord_flip() +
  scale_fill_manual(values = c("#5C8286",  "#BFBFBF")) +
  labs(x = "", y = "ICER ($/QALY)")

ggsave("DSA_less.pdf", dsa_less, height = 10, width = 18)

