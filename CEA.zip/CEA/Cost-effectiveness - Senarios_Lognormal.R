library(dplyr)
library(heemod)
library(flexsurv)
library(ggplot2)
library(tidyr)
library(parallel)


# read data
rm(list=ls(all=TRUE))
# setwd("~/TWT")
setwd("E:/Keynote-671 Cost-Effectiveness/rstudio-export0626")
# load("res_mod.RData")
mycsvfile=list.files(pattern = '*.csv')
list2env(lapply(setNames(mycsvfile,make.names(gsub('*.csv$',"",mycsvfile))),
                read.csv,header=T),envir = .GlobalEnv)

EFS_EA <- parametersEFS..Pembrolizumab.[10, ]
EFS_CA <- parametersEFS..Placebo.[10, ]
OS_EA <- parametersOS..Pembrolizumab.[10, ]
OS_CA <- parametersOS..Placebo.[4, ]

P_EA <- function(t) {
  return(exp(-Hgengamma(
    t *21/30,
    EFS_EA[, 4],
    EFS_EA[, 5],
    EFS_EA[, 6]
  )))
}

P_CA <- function(t) {
  return(exp(-Hgengamma(
    t *21/30,
    EFS_CA[, 4],
    EFS_CA[, 5],
    EFS_CA[, 6]
  )))
}

S_EA <- function(t) {
  return(exp(-Hlnorm(
    t *21/30,
    OS_EA[, 4],
    OS_EA[, 5]
  )))
}

S_CA <- function(t) {
  return(exp(-Hlnorm(
    t * 21 / 30,
    OS_CA[, 4],
    OS_CA[, 5]
  )))
}


# 转换概率
mod_par <- define_parameters(
  natrual_death = get_who_mr(
    age = 65 + (markov_cycle * 21 / 365),
    country = "USA",
    local = T
  ) %>%
    rescale_prob(p = ., to = 21 / 365),
  nS_R_death = 0.02342007, #63/2690
  S_R_death = rate_to_prob(nS_R_death, to = 21/30),
  #pembrolizumab
  pNTD_pem = natrual_death,
  nNTS_pem = 0.8636364, #342 / 396
  pNTP_pem = ifelse(markov_cycle > 162,
                    0,
    (P_EA(markov_cycle) - P_EA(markov_cycle + 1)) / P_EA(markov_cycle) - natrual_death
    ),
  pNTS_pem = ifelse(markov_cycle < 5,
                    0,
                    ifelse(markov_cycle < 7,
                           rescale_prob(p = nNTS_pem, from = 2) - pNTD_pem - pNTP_pem,
                           0)
  ),
  pNTN_pem = 1 - pNTD_pem - pNTS_pem - pNTP_pem,
  pSTP_pem = ifelse(markov_cycle > 162,
                    0,
    (P_EA(markov_cycle) - P_EA(markov_cycle + 1)) / P_EA(markov_cycle) - natrual_death
    ),
  pSTD_pem = ifelse(state_time == 1,
                    S_R_death,
                    natrual_death),
  nSTA_pem = 0.8479532, #290 / 342
  pSTA_pem = ifelse(markov_cycle < 6,
                    0,
                    ifelse(markov_cycle < 11,
                           rescale_prob(p = nSTA_pem, from = 5),
                           0)
  ),
  pSTS_pem = 1 - pSTP_pem - pSTD_pem - pSTA_pem,
  pATP_pem = ifelse(markov_cycle > 162,
                    0,
                    (P_EA(markov_cycle) - P_EA(markov_cycle + 1)) / P_EA(markov_cycle) - natrual_death
                    ),
  pATD_pem = natrual_death,
  pATA_pem = 1 - pATP_pem - pATD_pem,
  pPTD_pem = ifelse(
    S_EA(markov_cycle + 1) - P_EA(markov_cycle + 1) > 0,
    (S_EA(markov_cycle) - S_EA(markov_cycle + 1)) /
      (S_EA(markov_cycle) - P_EA(markov_cycle + 1)) + natrual_death,
    1
  ),
  pPTP_pem = 1 - pPTD_pem,
  #placebo
  pNTD_pla = natrual_death,
  nNTS_pla = 0.8375,  #335 / 400
  pNTP_pla = ifelse(markov_cycle > 162,
                    0,
    (P_CA(markov_cycle) - P_CA(markov_cycle + 1)) / P_CA(markov_cycle) - natrual_death
  ),
  pNTS_pla = ifelse(markov_cycle < 5,
                    0,
                    ifelse(markov_cycle < 7,
                           rescale_prob(p = nNTS_pla, from = 2) - pNTP_pla - pNTD_pla,
                           0)
  ),
  pNTN_pla = 1 - pNTD_pla - pNTS_pla - pNTP_pla,
  pSTP_pla = ifelse(markov_cycle > 162,
                    0,
    (P_CA(markov_cycle) - P_CA(markov_cycle + 1)) / P_CA(markov_cycle) - natrual_death
    ),
  pSTD_pla = ifelse(state_time == 1,
                    S_R_death,
                    natrual_death),
  nSTA_pla = 0.7970149, #267 / 335
  pSTA_pla = ifelse(markov_cycle < 6,
                    0,
                    ifelse(markov_cycle < 11,
                           rescale_prob(p = nSTA_pla, from = 5),
                           0)
  ),
  pSTS_pla = 1 - pSTP_pla - pSTD_pla - pSTA_pla,
  pATP_pla = ifelse(markov_cycle > 162,
                    0,
    (P_CA(markov_cycle) - P_CA(markov_cycle + 1)) / P_CA(markov_cycle) - natrual_death
    ),
  pATD_pla = natrual_death,
  pATA_pla = 1 - pATP_pla - pATD_pla,
  pPTD_pla = ifelse(
    S_CA(markov_cycle + 1) > P_CA(markov_cycle + 1),
    (S_CA(markov_cycle) - S_CA(markov_cycle + 1)) /
      (S_CA(markov_cycle) - P_CA(markov_cycle + 1)) + natrual_death,
    1
  ), 
  pPTP_pla = 1 - pPTD_pla
)

#停药概率
mod_par <- modify(
  mod_par,
  nDiscontinue_pem_neo = 0.2544081, #101/397,
  nDiscontinue_pla_neo = 0.255, #102/400,
  nDiscontinue_pem_adj = 0.3548387, #88/(290-42),
  nDiscontinue_pla_adj = 0.3648649, #81/(267-45),
  
  pDiscontinue_pem_neo = rate_to_prob(nDiscontinue_pem_neo, to = 1/4),
  pDiscontinue_pla_neo = rate_to_prob(nDiscontinue_pla_neo, to = 1/4),
  pDiscontinue_pem_adj = rate_to_prob(nDiscontinue_pem_adj, to = 1/13),
  pDiscontinue_pla_adj = rate_to_prob(nDiscontinue_pla_adj, to = 1/13)
)

#其他
mod_par <- modify(
  mod_par,
  Discount_rate = 0.03,
  BSA = 1.86,
  
  nNeutropenia_pem = 0.207,
  nAnemia_pem = 0.073,
  nThrombocytopenia_pem = 0.051,
  nNeutropenia_pla = 0.195,
  nAnemia_pla = 0.055,
  nThrombocytopenia_pla = 0.060,
  
  pNeutropenia_pem = rescale_prob(p = nNeutropenia_pem, from = 4),
  pAnemia_pem = rescale_prob(p = nAnemia_pem, from = 4),
  pThrombocytopenia_pem = rescale_prob(p = nThrombocytopenia_pem, from = 4),
  pNeutropenia_pla = rescale_prob(p = nNeutropenia_pla, from =4),
  pAnemia_pla = rescale_prob(p = nAnemia_pla, from = 4),
  pThrombocytopenia_pla = rescale_prob(p = nThrombocytopenia_pla, from = 4),
  Discount = rescale_discount_rate(Discount_rate, from = 365, to = 21)
)

#效用值
mod_par <- modify(
  mod_par,
  uRadiotherapy = 0.789,
  uSurgery = 0.725,
  uPF = 0.752,
  uPD = 0.653,
  uNeutropenia = 0.35,
  uAnemia = 0.037,
  uThrombocytopenia = 0.25,
  uAE_pem = uNeutropenia * pNeutropenia_pem * 21/365 +
    uAnemia*pAnemia_pem * 21/365 +
    uThrombocytopenia * pThrombocytopenia_pem * 21/365,
  uAE_pla = uNeutropenia * pNeutropenia_pla * 21/365 +
    uAnemia * pAnemia_pla * 21/365 +
    uThrombocytopenia * pThrombocytopenia_pla * 21/365,
  uSorR_pem = uRadiotherapy * (35-16)/342 + 
    uSurgery * 325/342,
  uSorR_pla = uRadiotherapy * (53-35)/335 + 
    uSurgery * 317/335,
  uNeo_pem_cycle = uPF * 21/365 - uAE_pem,
  uNeo_pla_cycle = uPF * 21/365 - uAE_pla,
  uPD_cycle = uPD * 21/365,
  uSorR_pem_cycle = uSorR_pem * 21/365,
  uSorR_pla_cycle = uSorR_pla * 21/365,
  uAdj_pem_cycle = uSorR_pem * 21/365,
  uAdj_pla_cycle = uSorR_pla * 21/365
)

#成本
mod_par <- modify(
  mod_par,
  cSurgery = 15687.42,
  cRadiotherapy = 16335.11,
  cPemetrexed = 6.45,
  cCisplatin = 0.32, 
  cGemcitabine = 0.02, 
  cPembrolizumab = 54.81,
  cChemo_iv_infusion_1hr = 132.16,
  cChemo_iv_infusion_addlhr = 28.47,
  cChemo_iv_infusion_each_addl_seq = 65.06,
  cFollow_up = 545.92,
  cEnd_of_life = 17909.24,
  cBest_supportive_care = 2572.255,
  cNeutropenia = 1276.52,
  cAnemia = 2024.32,
  cThrombocytopenia = 2220.14,
  cPembrolizumab_cycle = cPembrolizumab * 200,
  cCisplatin_cycle = cCisplatin * 75 * BSA,
  cPemetrexed_cycle = cPemetrexed * 500 * BSA,
  cGemcitabine_cycle = cGemcitabine * 1250 * BSA * 2,
  cAE_pem = cNeutropenia * pNeutropenia_pem +
    cAnemia * pAnemia_pem +
    cThrombocytopenia * pThrombocytopenia_pem,
  cAE_Placebo = cNeutropenia * pNeutropenia_pla +
    cAnemia * pAnemia_pla +
    cThrombocytopenia * pThrombocytopenia_pla,
  cPembrolizumab_infusion	= cChemo_iv_infusion_1hr,
  
  cCisplatin_Pemetrexed_infusion	= cChemo_iv_infusion_1hr +
    cChemo_iv_infusion_addlhr * 2 +
    cChemo_iv_infusion_each_addl_seq,
  
  cCisplatin_Gemcitabine_infusion	= cChemo_iv_infusion_1hr +
    cChemo_iv_infusion_addlhr * 2 +
    cChemo_iv_infusion_each_addl_seq,
  
  cPem_Cis_Pemet_cycle = cPembrolizumab_cycle + cCisplatin_cycle +
    cPemetrexed_cycle + cCisplatin_Pemetrexed_infusion,
  cPem_Cis_Gem_cycle = cPembrolizumab_cycle + cCisplatin_cycle +
    cGemcitabine_cycle + cCisplatin_Gemcitabine_infusion,
  
  cCis_Pemet_cycle = cCisplatin_cycle +
    cPemetrexed_cycle + cCisplatin_Pemetrexed_infusion,
  cCis_Gem_cycle = cCisplatin_cycle +
    cGemcitabine_cycle + cCisplatin_Gemcitabine_infusion,
  
  cAdj_pem_cycle = cPembrolizumab_cycle + cPembrolizumab_infusion,
  
  cNeo_pem_cycle = cPem_Cis_Pemet_cycle * 222/396 +
    cPem_Cis_Gem_cycle * 174/396,
  cNeo_pla_cycle = cCis_Pemet_cycle * 225/399 +
    cCis_Gem_cycle * 175/399,
  
  cSorR_pem = cSurgery * 325/342 + cRadiotherapy * 35/342,
  cSorR_pla = cSurgery * 317/335 + cRadiotherapy * 53/335,
  
  cNeo_pem = ifelse(state_time < 5,
                    cNeo_pem_cycle + cFollow_up + cAE_pem,
                    cFollow_up + cAE_pem),
  cNeo_pla = ifelse(state_time < 5,
                    cNeo_pla_cycle + cFollow_up + cAE_pem,
                    cFollow_up + cAE_pem),
  
  cPost_pem = ifelse(state_time == 1,
                     cSorR_pem + cFollow_up,
                     cFollow_up),
  cPost_pla = ifelse(state_time == 1,
                     cSorR_pla + cFollow_up,
                     cFollow_up),
  
  cAdj_pem = ifelse(state_time < 14,
                    cAdj_pem_cycle + cFollow_up,
                    cFollow_up),
  cAdj_pla = cFollow_up,
  
  cPD_pem_cycle = ifelse(state_time == 1,
                         cRadiotherapy +
                           cCis_Pemet_cycle * 226/397 +
                           cCis_Gem_cycle * 171/397 +
                           cFollow_up,
                         ifelse(state_time > 6,
                                cFollow_up,
                                cCis_Pemet_cycle * 226/397 +
                                  cCis_Gem_cycle * 171/397 +
                                  cFollow_up
                         )),
  cPD_pla_cycle = ifelse(state_time == 1,
                         cRadiotherapy +
                           cCis_Pemet_cycle * 227/400 +
                           cCis_Gem_cycle * 173/400 +
                           cFollow_up,
                         ifelse(state_time > 6,
                                cFollow_up,
                                cCis_Pemet_cycle * 226/400 +
                                  cCis_Gem_cycle * 171/400 +
                                  cFollow_up
                         )),
  
  cD = ifelse(state_time == 1,
              cEnd_of_life,
              0)
)



# Markov Model

mat_trans_pem <- define_transition(
  state_names=c("Neoadjuvant", "post_SR", "PD", "Adjuvant","Death"),
  pNTN_pem, pNTS_pem,  pNTP_pem,  0,        pNTD_pem,
  0,        pSTS_pem,  pSTP_pem,  pSTA_pem, pSTD_pem,
  0,        0,         pPTP_pem,  0,        pPTD_pem,
  0,        0,         pATP_pem,  pATA_pem, pATD_pem,
  0,        0,         0,         0,        1
)
#plot(mat_trans_pem)
mat_trans_pla <- define_transition(
  state_names=c("Neoadjuvant", "post_SR", "PD", "Adjuvant","Death"),
  pNTN_pla, pNTS_pla,  pNTP_pla, 0,        pNTD_pla,
  0,        pSTS_pla,  pSTP_pla, pSTA_pla, pSTD_pla,
  0,        0,         pPTP_pla, 0,        pPTD_pla,
  0,        0,         pATP_pla, pATA_pla, pATD_pla,
  0,        0,         0,        0,        1
)
#plot(mat_trans_pla)

### 定义各个状态下的参数值

state_Neo <- define_state(
  cost = dispatch_strategy(
    pem = discount(cNeo_pem, r = Discount),
    pla = discount(cNeo_pla, r = Discount)),
  qaly = dispatch_strategy(
    pem = discount(uNeo_pem_cycle, r = Discount),
    pla = discount(uNeo_pla_cycle, r = Discount))
)

state_Post <- define_state(
  cost = dispatch_strategy(
    pem = discount(cPost_pem, r = Discount),
    pla = discount(cPost_pla, r = Discount)),
  qaly = dispatch_strategy(
    pem = discount(uSorR_pem_cycle, r = Discount),
    pla = discount(uSorR_pla_cycle, r = Discount)
  )
)

state_Adj <- define_state(
  cost = dispatch_strategy(
    pem = discount(cAdj_pem, r = Discount),
    pla = discount(cAdj_pla, r = Discount)
  ),
  qaly = dispatch_strategy(
    pem = discount(uAdj_pem_cycle, r = Discount),
    pla = discount(uAdj_pla_cycle, r = Discount)
  )
)

state_PD <- define_state(
  cost = dispatch_strategy(
    pem = discount(cPD_pem_cycle, r = Discount),
    pla = discount(cPD_pla_cycle, r = Discount)
  ),
  qaly = discount(uPD_cycle, r = Discount)
)

state_D <- define_state(cost = discount(cD, r = Discount), qaly = 0)


###定义治疗方案
strat_pem <- define_strategy(
  transition = mat_trans_pem,
  Neoadjuvant = state_Neo,
  post_SR = state_Post,
  Adjuvant = state_Adj,
  PD = state_PD,
  Death = state_D)

strat_pla <- define_strategy(
  transition = mat_trans_pla,
  Neoadjuvant = state_Neo,
  post_SR = state_Post,
  Adjuvant = state_Adj,
  PD = state_PD,
  Death = state_D)

#load("res_mod.RData")


##运行模型
 start <- Sys.time()

 res_mod <- run_model(
   parameters = mod_par,
   init = c(100, 0, 0, 0, 0),
   pem = strat_pem,
   pla = strat_pla,
   state_time_limit = 15,
   cycles = 174,
   cost = cost,
   effect = qaly,
   method = "life-table")

 end <- Sys.time()
 end - start
 
save(res_mod, file = "res_mod_lognormal.RData")
 
##Markov模型用寿命表法模拟队列生存分析图
 pdf("res_mod.pdf", width = 10, height = 8)
 plot(res_mod)
 dev.off()

