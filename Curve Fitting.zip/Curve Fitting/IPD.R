#read data
rm(list=ls(all=TRUE))
setwd("E:\\Keynote-671 Cost-Effectiveness\\KM raw data")
mycsvfile=list.files(pattern = '*.csv')
list2env(lapply(setNames(mycsvfile,make.names(gsub('*.csv$',"",mycsvfile))),
                read.csv,header=T),envir = .GlobalEnv)
setwd("E:\\Keynote-671 Cost-Effectiveness\\Curve Fitting")
library(IPDfromKM)
library(survminer)

#reconstruct IPD

file <- "OS"
#positive
data_positive<-get(paste0(file, "_EA"))
attach(data_positive)
predata <- preprocess(dat = data.frame(time, percent),
                      trisk = as.numeric(na.omit(trisk)), 
                      nrisk = as.numeric(na.omit(nrisk)), 
                      maxy = 1)
estdata_EA <- getIPD(prep=predata, armID=1, tot.events=NULL)
summary(estdata_EA)
plot(estdata_EA)

tiff(filename = paste0("estimated curves\\", file, "_EA.tif"),  width=900, height=600)
plot(estdata_EA)
dev.off()

#negative
data_negative<-get(paste0(file, "_CA"))
attach(data_negative)
predata <- preprocess(dat = data.frame(time, percent),
                      trisk = as.numeric(na.omit(trisk)), 
                      nrisk = as.numeric(na.omit(nrisk)), 
                      maxy = 1)
estdata_CA<- getIPD(prep=predata, armID=1, tot.events=NULL)
summary(estdata_CA)
plot(estdata_CA)

tiff(filename = paste0("estimated curves\\", file, "_CA.tif"),  width=900, height=600)
plot(estdata_CA)
dev.off()

#survAUC
CA<-estdata_CA$IPD
CA$treat<-1
EA<-estdata_EA$IPD
EA$treat<-2

write.csv(CA, file = paste0("IPD\\",file, "_CA.csv"), row.names = F)
write.csv(EA, file = paste0("IPD\\",file, "_EA.csv"), row.names = F)

#EA vs CA
nPvsN<-rbind(EA,CA)
set.seed(32486)
h <- runif(nrow(nPvsN))
PvsN<-nPvsN[order(h),]
fit <- survfit(survival::Surv(PvsN$time, PvsN$status, type = "right") ~ treat, data = PvsN)
all.fit <- survival::coxph(survival::Surv(PvsN$time, PvsN$status, type = "right") ~ treat,
                           x=TRUE, y=TRUE, data=PvsN, ties = "exact")
x <- summary(all.fit)
p.value<-signif(x$sctest["pvalue"], digits=2)
HR <-signif(x$coef[2], digits=2);#exp(beta)
HR.confint.lower <- signif(x$conf.int[,"lower .95"], 2)
HR.confint.upper <- signif(x$conf.int[,"upper .95"],2)
res<-c(HR, HR.confint.lower, HR.confint.upper,  p.value)
names(res)<-c("HR", "CI95L", "CI95U", "Log-rank p.value")
res_PvsN<-as.data.frame(t(as.data.frame(res, check.names=F)))

ggsurvplot(fit, # 创建的拟合对象
           data = PvsN,  # 指定变量数据来源
           conf.int = TRUE, # 显示置信区间
           palette = "lancet",
           pval = TRUE, # 添加P值
           pval.method = TRUE,
           break.x.by = 6,
           surv.median.line = "hv",  # 添加中位生存时间线
           risk.table = TRUE, # 添加风险表
           xlab = "Follow up time(months)", # 指定x轴标签
           legend = c(0.9,0.9), # 指定图例位置
           legend.title = "", # 设置图例标题
           legend.labs = c("Placebo","Pembrolizumab")) # 指定图例分组标签

tiff(filename = paste0("KM curves\\", file, "_EAvsCA.tif"),  width=900, height=600)
ggsurvplot(fit, # 创建的拟合对象
           data = PvsN,  # 指定变量数据来源
           conf.int = TRUE, # 显示置信区间
           palette = "lancet",
           pval = TRUE, # 添加P值
           pval.method = TRUE,
           break.x.by = 6,
           surv.median.line = "hv",  # 添加中位生存时间线
           risk.table = TRUE, # 添加风险表
           xlab = "Follow up time(months)", # 指定x轴标签
           legend = c(0.9,0.9), # 指定图例位置
           legend.title = "", # 设置图例标题
           legend.labs = c("Placebo","Pembrolizumab")) # 指定图例分组标签
dev.off()

res <- res_PvsN
res[,"Comparisons"] <- "EA vs CA"
res[,"No. (I)"] <- data_positive[1,"nrisk"]
res[,"No. (C)"] <- data_negative[1,"nrisk"]
res <- res %>% dplyr::select('Comparisons', 'No. (I)', 'No. (C)', everything())
write.csv(res, file = paste0("HR\\",file, ".csv"), row.names = F)

