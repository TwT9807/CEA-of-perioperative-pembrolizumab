library(dplyr)
library(survival)
library(flexsurv)
library(survminer)
library(colorspace)
library(showtext)

#read data
rm(list=ls(all=TRUE))
setwd("E:\\Keynote-671 Cost-Effectiveness\\Curve Fitting\\IPD")
mycsvfile=list.files(pattern = '*.csv')
list2env(lapply(setNames(mycsvfile,make.names(gsub('*.csv$',"",mycsvfile))),
                read.csv,header=T),envir = .GlobalEnv)
setwd("E:\\Keynote-671 Cost-Effectiveness\\Curve Fitting")

data_name <- "OS_CA"
data <- get(data_name)
data_name <- data_name %>% gsub("_EA", " (Pembrolizumab)", .) %>%
  gsub("_CA", " (Placebo)", .)

dists <- c("exp", "weibull", "llogis", "lnorm", "gengamma", "gamma", "gompertz")

parameters <- data.frame()
y <- data.frame()
x <- seq(from = 0, to = 200, by = 1)

for (dist in dists) {
  model <- flexsurvreg(Surv(data$time, data$status, type="right")~1,
                   dist = dist, data = data)
  AIC <- AIC(model)
  BIC <- BIC(model)
  
  if (dist == "exp") {
    parameter <- c(dist, AIC, BIC,
                   model$res[1],
                   rep(NA, 2))
    y1 <- c(dist, exp(-Hexp(x, rate = model$res[1])))
  }
  if (dist == "weibull") {
    parameter <- c(dist, AIC, BIC,
                   model$res[1],
                   model$res[2],
                   NA)
    y1 <- c(dist, exp(-Hweibull(x, shape = model$res[1], scale = model$res[2])))
  }
  if (dist == "llogis") {
    parameter <- c(dist, AIC, BIC,
                   model$res[1],
                   model$res[2],
                   NA)
    y1 <- c(dist, exp(-Hllogis(x, shape = model$res[1], scale = model$res[2])))               
  }
  if (dist == "lnorm") {
    parameter <- c(dist, AIC, BIC,
                   model$res[1],
                   model$res[2],
                   NA)
    y1 <- c(dist, exp(-Hlnorm(x, meanlog = model$res[1], sdlog = model$res[2])))
  }
  if (dist == "gengamma") {
    parameter <- c(dist, AIC, BIC,
                   model$res[1],
                   model$res[2],
                   model$res[3])
    y1 <- c(dist, exp(-Hgengamma(x, mu = model$res[1], sigma = model$res[2], Q = model$res[3])))
  }
  if (dist == "gamma") {
    parameter <- c(dist, AIC, BIC,
                   model$res[1],
                   model$res[2],
                   NA)
    y1 <- c(dist, exp(-Hgamma(x, shape = model$res[1], rate = model$res[2])))
  }
  if (dist == "gompertz") {
    parameter <- c(dist, AIC, BIC,
                   model$res[1],
                   model$res[2],
                   NA)
    y1 <- c(dist, exp(-Hgompertz(x, shape = model$res[1], rate = model$res[2])))
  }
  parameters <- rbind(parameters, parameter)
  y <- rbind(y, y1)
}

colnames(parameters) <-
  c("model", "AIC", "BIC", "rate/shape/meanlog/mu", "scale/sdlog/rate", "Q")
rownames(y) <- y[, 1]
y <- y[, -1]

min <- subset(parameters,
              parameters$AIC == min(parameters$AIC))
parameters <- rbind(parameters, c(rep(NA, 6)), c("min", rep(NA, 5)), min)

write.csv(parameters, file = paste0("parameters", data_name, ".csv"),
          row.names = F)

# plot it
fit <- survfit(survival::Surv(data$time, data$status, type = "right") ~ 1, data)
colors <- qualitative_hcl(7, palette = "Set 2")
showtext_auto(enable = TRUE)
font_add('Arial', 'arial.ttf')

plot <-
  ggsurvplot(
    fit,
    data,
    conf.int = FALSE,
    palette = "dark grey",
    break.x.by = 10,
    xlim = c(0, 150),
    axes.offset = F,
    legend = "right"
  )$plot +
  geom_line(data = data.frame(), aes(x = x, y = as.numeric(y[1, ]),
                                     color = "Exponential")) +
  geom_line(data = data.frame(), aes(x = x, y = as.numeric(y[2, ]),
                                     color = "Weibull")) +
  geom_line(data = data.frame(), aes(x = x, y = as.numeric(y[3, ]),
                                     color = "Loglogistic")) +
  geom_line(data = data.frame(), aes(x = x, y = as.numeric(y[4, ]),
                                     color = "Lognormal")) +
  geom_line(data = data.frame(), aes(x = x, y = as.numeric(y[5, ]),
                                     color = "Gengamma")) +
  geom_line(data = data.frame(), aes(x = x, y = as.numeric(y[6, ]),
                                     color = "Gamma")) +
  geom_line(data = data.frame(), aes(x = x, y = as.numeric(y[7, ]),
                                     color = "Gompertz")) +
  scale_color_manual(
    name = "Distributions",
    values = c(
      "Exponential" = colors[1],
      "Weibull" = colors[2],
      "Loglogistic" = colors[3],
      "Lognormal" = colors[4],
      "Gengamma" = colors[5],
      "Gamma" = colors[6],
      "Gompertz" = colors[7]
    )
  ) +
  ggtitle(paste("Estimated Curve for", data_name)) +
  theme(legend.title = element_text(face = "bold"),
        plot.title = element_text(face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold"))


ggsave(paste0("E:\\Keynote-671 Cost-Effectiveness\\Curve Fitting\\",
              data_name, ".pdf"),
       plot = plot, device = "pdf", width = 24, height = 20,
       units = "cm")







