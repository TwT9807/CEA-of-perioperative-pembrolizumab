library(dplyr)
library(survival)
library(flexsurv)
library(survminer)
library(colorspace)
library(showtext)


#read data
rm(list=ls(all=TRUE))
setwd("E:\\Keynote-671 Cost-Effectiveness\\Curve Fitting\\IPD")
mycsvfile=list.files(pattern = '*.csv')
list2env(lapply(setNames(mycsvfile,make.names(gsub('*.csv$',"",mycsvfile))),
                read.csv,header=T),envir = .GlobalEnv)
setwd("E:\\Keynote-671 Cost-Effectiveness\\Curve Fitting")


colors <- qualitative_hcl(2, palette = "Set 2")

# EFS_EA_Gengamma CA_gengamma

data_name_EA <- "EFS_EA"
data_EA <- get(data_name_EA)
data_EA$treat <- 1
data_name_EA <- data_name_EA %>% gsub("_EA", " (Pembrolizumab)", .) %>%
  gsub("_CA", " (Placebo)", .)
model_EA <- flexsurvreg(Surv(data_EA$time, data_EA$status, type="right")~1,
                     dist = "gengamma", data = data_EA)

data_name_CA <- "EFS_CA"
data_CA <- get(data_name_CA)
data_CA$treat <- 2
data_name_CA <- data_name_CA %>% gsub("_EA", " (Pembrolizumab)", .) %>%
  gsub("_CA", " (Placebo)", .)
model_CA <- flexsurvreg(Surv(data_CA$time, data_CA$status, type="right")~1,
                        dist = "gengamma", data = data_CA)
  

showtext_auto(enable = TRUE)
font_add('Arial', 'arial.ttf')
colors <- diverging_hcl(4, palette = "Blue-Red 2")



pdf("EFS.pdf", height = 10.5, width = 10)
plot(model_EA, col = colors[1],
     xlab = "Time (months)",
     ylab = "Probability of Event-free survival", 
     font.lab = 2,
     main = "Eplicated and Estimated Curves for Event-free Survival",
     col.obs = colors[2], lwd.obs = 2)
lines(survfit(Surv(data_CA$time, data_CA$status, type="right")~1,
              data=data_CA), col= colors[3], lty=1, lwd=2, ylim=NULL)
plot(model_CA, col = colors[4], add = TRUE)
legend(
  "bottomleft",
  legend = c("Estimated Curve for EFS (Pembrolizumab)",
             "Estimated Curve for EFS (Placebo)",
             "K-M Curve for EFS (Pembrolizumab)",
             "K-M Curve for EFS (Placebo)"),
  lwd = 2,
  col = c(colors[1], colors[4], colors[2], colors[3])
)
dev.off()

# OS_EA_Lognormal CA_Weibull

data_name_EA <- "OS_EA"
data_EA <- get(data_name_EA)
data_EA$treat <- 1
model_EA <- flexsurvreg(Surv(data_EA$time, data_EA$status, type="right")~1,
                        dist = "lnorm", data = data_EA)

data_name_CA <- "OS_CA"
data_CA <- get(data_name_CA)
data_CA$treat <- 2
model_CA <- flexsurvreg(Surv(data_CA$time, data_CA$status, type="right")~1,
                        dist = "weibull", data = data_CA)


showtext_auto(enable = TRUE)
font_add('Arial', 'arial.ttf')
colors <- diverging_hcl(4, palette = "Blue-Red 2")



pdf("OS.pdf", height = 10.5, width = 10)
plot(model_EA, col = colors[1],
     xlab = "Time (months)",
     ylab = "Probability of Overall Survival", 
     font.lab = 2,
     main = "Eplicated and Estimated Curves for Overall Survival",
     col.obs = colors[2], lwd.obs = 2)
lines(survfit(Surv(data_CA$time, data_CA$status, type="right")~1,
              data=data_CA), col= colors[3], lty=1, lwd=2, ylim=NULL)
plot(model_CA, col = colors[4], add = TRUE)
legend(
  "bottomleft",
  legend = c("Estimated Curve for OS (Pembrolizumab)",
             "Estimated Curve for OS (Placebo)",
             "K-M Curve for OS (Pembrolizumab)",
             "K-M Curve for OS (Placebo)"),
  lwd = 2,
  col = c(colors[1], colors[4], colors[2], colors[3])
)
dev.off()

